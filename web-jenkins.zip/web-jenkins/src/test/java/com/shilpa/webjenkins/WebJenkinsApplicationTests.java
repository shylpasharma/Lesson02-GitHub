package com.shilpa.webjenkins;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebJenkinsApplicationTests {

	@Test
	void contextLoads() {
	}

}
